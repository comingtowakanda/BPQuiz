export const ADD_OPTIONS = 'add_options';
export const HIDE_MODAL = 'hide_modal';
