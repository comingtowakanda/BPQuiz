export default function() {
  return [
    {
      id: 1,
      rapper: 'The Notorious B.I.G.',
      image: 'rapper1.jpg',
      description: 'You are a force to be reckoned with, but there is a quiet intellectual buried deep inside. Even though you are on the heavy side, people love you!'
    },
    {
      id: 2,
      rapper: '2Pac',
      image: 'rapper2.jpg',
      description: 'You love to party, and your smile lights up the room. You must be a regular at the gym because your ab muscles are on point!'
    },
    {
      id: 3,
      rapper: 'Jay-Z',
      image: 'rapper3.jpg',
      description: 'You pull yourself up by the bootstraps and are able to create something big out of nothing. Your everyday hussle is going to pay off soon!'
    },
    {
      id: 4,
      rapper: 'Andre 3000',
      image: 'rapper4.jpg',
      description: 'You are a weirdo, but totally in a good way! While everyone else is caught up in the rat race of life, you walk to the beat of your own drum.'
    },
    {
      id: 5,
      rapper: 'Snoop Dogg',
      image: 'rapper5.jpg',
      description: 'You get high on life, amongst other things! Nothing can bring you down because you are the chillest person in the world.'
    },
    {
      id: 6,
      rapper: 'Lauryn Hill',
      image: 'rapper6.jpg',
      description: 'You are a jack of all trades, and a master of all of them! You are a beautiful person both inside and out.'
    }
  ];
}
